﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            const string mutexName = "MutexExample4";
            Mutex m;
            try
            {
                m = Mutex.OpenExisting(mutexName);
            }
            catch (WaitHandleCannotBeOpenedException)
            {

                Console.WriteLine("Mutex does not exist.");
                m = new Mutex(false, mutexName);
                //  m.ReleaseMutex();
            }

            //    Console.ReadLine();
            //    m.WaitOne();

            if (m == null)
            {
                Console.WriteLine("Mutex does not exist else...");
            }
            else
            {
                Console.WriteLine("Exist");
            }
            int i = 0;
            while (true)
            {
                m.WaitOne();
                Console.WriteLine(i++);
                m.ReleaseMutex();
            }






            m.WaitOne();
            
            Console.WriteLine("In Critical area for C#...");
            Console.ReadLine();
            
            m.ReleaseMutex();

            Console.WriteLine("Exit critical area for C#");

            Console.ReadLine();
        }
    }
}

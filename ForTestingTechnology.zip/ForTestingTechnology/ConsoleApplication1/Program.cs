﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using ForTestingTechnology;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime temp = DateTime.Parse("2017-10-30 11:06:25.810");

            Console.WriteLine(temp < DateTime.Parse("31.10.2017 00:00:00"));

            //int y = Int32.Parse(Console.ReadLine());

            //try
            //{
            //    int i = 5/y;
            //}
            //catch (Exception ex)
            //{
            //  //  Console.WriteLine(ex);
            //    SmtpClientHelper.SendErrorToEmail(ex, "Произошла непредвиденная ошибка");
            //}



            /*MemoryMappedFile MemoryQUIKCommand = MemoryMappedFile.CreateOrOpen("Memory", 200000, MemoryMappedFileAccess.ReadWrite);
            StreamReader SR_QUIKCommand = new StreamReader(MemoryQUIKCommand.CreateViewStream(), System.Text.Encoding.Default);
            StreamWriter SW_QUIKCommand = new StreamWriter(MemoryQUIKCommand.CreateViewStream(), System.Text.Encoding.Default);

            Program.SetQUIKCommandData(SW_QUIKCommand, "Command From C#");

            Console.WriteLine("Done");*/


            Console.ReadLine();
        }

        private static void SetQUIKCommandData(StreamWriter SW_QUIKCommand,  string Data = "")
        {
            //Если нужно отправить команду
            if (Data != "")
            {
                //Дополняет строку команды "нулевыми байтами" до нужной длины
                for (int i = Data.Length; i < 256; i++) Data += "\0";
            }
            else //Если нужно очистить память
            {
                //Заполняет строку для записи "нулевыми байтами"
                for (int i = 0; i < 256; i++) Data += "\0";
            }
            //Встает в начало
            SW_QUIKCommand.BaseStream.Seek(0, SeekOrigin.Begin);
            //Записывает строку
            SW_QUIKCommand.Write(Data);
            //Сохраняет изменения в памяти
            SW_QUIKCommand.Flush();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using NLog;

namespace YotaDownloadRegistry
{
    public class Program
    {
        private static readonly ILogger Logger = LogManager.GetLogger("info");

        private static string _login = SzyfrowanieString.deszyfruj(ConfigurationManager.AppSettings.Get("login"));
        private static string _password = SzyfrowanieString.deszyfruj(ConfigurationManager.AppSettings.Get("password"));

        private static string _dateFrom = DateTime.Now.AddDays(-4).ToShortDateString();
        private static string _dateTo = DateTime.Now.ToShortDateString();

        private static string _path = @"\\RM0V047\Masterbase\R60549\input";//SzyfrowanieString.deszyfruj(ConfigurationManager.AppSettings.Get("path"));

        private static string _loginServer = SzyfrowanieString.deszyfruj("qxCNLWlmmqQervzTgNcUYw==");
        private static string _passwordServerLogin = SzyfrowanieString.deszyfruj("R5xF5GXjsfmsPQTpTXgbfA==");
        private static string _domian = SzyfrowanieString.deszyfruj(ConfigurationManager.AppSettings.Get("_domian"));
        static void Main(string[] args)
        {
            bool result = false;
            int counter = 0;
            try
            {
                while (!result)
                {
                    if (counter++ > 5)
                        throw new FileNotFoundException("Не удалось скачать файл");

                    result = Worker();

                    if (!result)
                        Thread.Sleep(TimeSpan.FromMinutes(10));
                }
            }
            catch (FileNotFoundException fe)
            {
                Logger.Fatal(fe);
                //           SmtpClientHelper.SendErrorToEmail(fe);
            }
            catch (Exception ex)
            {
                Logger.Fatal(ex);
                //          SmtpClientHelper.SendErrorToEmail(ex, "Произошла непредвиденная ошибка в работе сервиса");
            }


        }

        private static bool Worker()
        {
            // Thread.Sleep(10000);
            Logger.Info("Trying to authorize");

            CookieContainer cc = new CookieContainer();
            RequestToWeb("https://partner.yota.ru/new/login/", "POST", cc,
                Encoding.ASCII.GetBytes($@"login={_login}&password={_password}&_password={_password}"));

            Logger.Info("Authorized successfully");

            string result;

            Logger.Info("Create a request to create a link");
            int attempt = 0;
            do
            {
                result = RequestToWeb("https://partner.yota.ru/new/admin/reports/summary_register/csv/", "POST", cc,
                    Encoding.ASCII.GetBytes(
                        "report_select=summary_register&template_select=javascript%3Avoid%280%29" +
                        "&report_id=753&template_id=1982&report_fields%5B%5D=ACTION&report_fields%5B%5D=SHIPMENT_PARTNER" +
                        "&report_fields%5B%5D=COMMENTS&report_fields%5B%5D=A_APPL_FILL_RES&report_fields%5B%5D=RD_KD_PROCESSING_DATE" +
                        "&report_fields%5B%5D=RD_PARTNER&report_fields%5B%5D=AGENT&report_fields%5B%5D=RD_REG_DATE&report_fields%5B%5D=RD_SIGN_DATE" +
                        "&report_fields%5B%5D=ENROLLMENT_DATE&report_fields%5B%5D=INCOMING_TO_ARCH_DATE&report_fields%5B%5D=CITY" +
                        "&report_fields%5B%5D=SENT_TO_ARCH_BY_PARTNER&report_fields%5B%5D=PARTNER_ID&report_fields%5B%5D=CONTRACT_SING_DATE" +
                        "&report_fields%5B%5D=SRC_ICCID&report_fields%5B%5D=ID&report_fields%5B%5D=STATE_REGISTRY&report_fields%5B%5D=ORIGINAL_CITY" +
                        "&report_fields%5B%5D=AFM&report_fields%5B%5D=BOX&report_fields%5B%5D=ARCH_USER&report_fields%5B%5D=DMS_NUMBER" +
                        "&template_title=%D0%92%D1%81%D0%B5+%D0%BF%D0%BE%D0%BB%D1%8F&template_is_public=on&enrollment_datefrom=&enrollment_dateto=" +
                        $"&created_atfrom={_dateFrom}&created_atto={_dateTo}&sign_datefrom=&sign_dateto=&filename="));
                Thread.Sleep(attempt < 6 ? 1000 : 60000);
            } while (!Regex.IsMatch(result, "Генерация отчета с") && ++attempt < 11);
            if (attempt > 10)
                throw new Exception("Не смог сформировать ссылку... ");
            attempt = 0;

            Logger.Info("Waiting for the link to download...");
            attempt = 0;
            do
            {
                Thread.Sleep(10000);

                result = RequestToWeb("https://partner.yota.ru/new/admin/reports/summary_register/", "GET", cc);
            } while (!Regex.IsMatch(result, "Отчеты в обработке - отсутствуют") && ++attempt < 11);

            if (attempt > 10)
                throw new Exception("Не смог сформировать ссылку... ");
            else
                attempt = 0;

            Logger.Info("Link formed");

            Logger.Info("Search link...");

            string page = RequestToWeb("https://partner.yota.ru/new/admin/reports/summary_register/", "GET", cc);

            Regex regexLinkWithDate = new Regex($@"<td class=""minifilter-params"">с {_dateFrom} по {_dateTo}</td>");

            Regex regexSearchLink = new Regex(@"\<td\>\<a href=""\/new\/admin\/reports\/summary_register\/(?<Data>down\w{13})");

            Regex regexNoData = new Regex(@"<td class=""minifilter-params"">Данных не найдено</td>");

            MatchCollection matches = regexLinkWithDate.Matches(page);
            MatchCollection matchesLinks = regexSearchLink.Matches(page);
            MatchCollection matchesNoData = regexNoData.Matches(page);

            //Logger.Warn(matches.Count);
            //Logger.Warn(matchesLinks.Count);
            //Logger.Warn(matchesNoData.Count);
            //Logger.Warn(page);

            bool successfully = false;
            if (matches.Count == 1 && matchesLinks.Count == 1)
            {
                Logger.Info("Link found - start download");
                DownloadFile("https://partner.yota.ru/new/admin/reports/summary_register/" + matchesLinks[0].Groups[1].Value, _path, cc);
            }
            else if (matches.Count > 1 && matchesLinks.Count >= 1)
            {
                foreach (Match match in matchesLinks)
                {
                    if (match.Index > matches[0].Groups[0].Index && match.Index < matches[0].Groups[0].Index + 2030)
                    {
                        Logger.Info("Link found - start download");
                        DownloadFile("https://partner.yota.ru/new/admin/reports/summary_register/" + match.Groups[1].Value, _path, cc);
                        successfully = true;
                        break;
                    }
                }
                if (!successfully)
                    Logger.Info("Data for the specified period was not found");
            }
            else if (matchesLinks.Count == 0 && matchesNoData.Count >= 1)
            {
                Logger.Warn("Data for the specified period was not found");
            }

            Logger.Info("Work completed");

            return successfully;
        }

        public static string RequestToWeb(string link, string requestType, CookieContainer cc, byte[] buffer = null)
        {
            HttpWebRequest WebReq = (HttpWebRequest)WebRequest.Create(link);//Строка для запроса

            WebReq.CookieContainer = cc;//включаем куки
            WebReq.Method = requestType;
            WebReq.ContentType = "application/x-www-form-urlencoded";
            WebReq.Proxy = new WebProxy("192.168.0.6", 8080);
            WebReq.Timeout = 30000;
            WebReq.UserAgent = @"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36";
            if (buffer != null)
                WebReq.ContentLength = buffer.Length;

            HttpWebResponse WebResp;
            string newPageCode = String.Empty;
            try
            {
                if (buffer != null)
                {
                    Stream PostData = WebReq.GetRequestStream();
                    PostData.Write(buffer, 0, buffer.Length);
                    PostData.Close();
                }
                WebResp = (HttpWebResponse)WebReq.GetResponse();
                try
                {
                    var sr = new StreamReader(WebResp.GetResponseStream());
                    newPageCode = sr.ReadToEnd().Trim();
                }
                catch (Exception ex)
                {
                    Logger.Error(ex);
                    //             SmtpClientHelper.SendErrorToEmail(ex, "Произошла непредвиденная ошибка в работе сервиса");
                    throw;
                }

            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                //        SmtpClientHelper.SendErrorToEmail(ex, "Произошла непредвиденная ошибка в работе сервиса");
                throw;
            }
            return newPageCode;
        }

        public static void DownloadFile(string link, string path, CookieContainer cc)
        {
            HttpWebRequest WebReq =
                    (HttpWebRequest)WebRequest.Create(link);
            WebReq.CookieContainer = cc;
            WebReq.Method = "GET";
            WebReq.Timeout = 30000;
            WebReq.ContentType = "application/x-www-form-urlencoded";
            WebReq.Proxy = new WebProxy("192.168.0.6", 8080);
            WebReq.UserAgent = @"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36";

            //Для авинхронного запроса необходимо раскомментировать код тут и в методе DownloadResponseAsync (и заменить у него сигнатуру на комментную) и закоментить не асинхронный вызов
            //Может быть нужно, если потребуется сразу много ссылок сформировать и скачать или что-то делать пока скачивается файл
            //  IAsyncResult result = WebReq.BeginGetResponse(new AsyncCallback(DownloadResponseAsync), WebReq);

            HttpWebResponse webResp = (HttpWebResponse)WebReq.GetResponse();

            DownloadResponseAsync(webResp, path);
        }

        public static void DownloadResponseAsync(HttpWebResponse webResponse, string path)            //(IAsyncResult asyncResult)
        {
            long total = 0;
            int received = 0;
            Logger.Info(Environment.UserName.ToString());
            //  HttpWebRequest webRequest = (HttpWebRequest)asyncResult.AsyncState;
            //var impersonationContext = new WrappedImpersonationContext(_domian, _loginServer, _passwordServerLogin);
            //impersonationContext.Enter();
            try
            {
                Logger.Info(Environment.UserName.ToString());
                //using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.EndGetResponse(asyncResult))
                //{
                byte[] buffer = new byte[1024];

                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);

                FileStream fileStream = File.OpenWrite(path + $@"\Yota_Registry_{DateTime.Now.ToShortDateString()}.csv");
                using (Stream input = webResponse.GetResponseStream())
                {
                    int size = input.Read(buffer, 0, buffer.Length);
                    while (size > 0)
                    {
                        fileStream.Write(buffer, 0, size);
                        received += size;

                        size = input.Read(buffer, 0, buffer.Length);
                    }
                }

                fileStream.Flush();
                fileStream.Close();

                Logger.Info("File successfully downloaded");

            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                //            SmtpClientHelper.SendErrorToEmail(ex, "Произошла непредвиденная ошибка в работе сервиса");
                throw;
            }
            finally
            {
           //     impersonationContext.Leave();
            }
        }
    }
}